

###### (Automatically generated documentation)

# AedgOfficeSwh

## Description


## Modeler Description


## Measure Type
ModelMeasure

## Taxonomy


## Arguments


### Total Cost for SWH System ($).

**Name:** costTotalSwhSystem,
**Type:** Double,
**Units:** ,
**Required:** true,
**Model Dependent:** false

### Total Number of Employees.

**Name:** numberOfEmployees,
**Type:** Integer,
**Units:** ,
**Required:** true,
**Model Dependent:** false




