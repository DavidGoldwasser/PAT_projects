

###### (Automatically generated documentation)

# AedgSmallToMediumOfficeElectricEquipmentControls

## Description


## Modeler Description


## Measure Type
ModelMeasure

## Taxonomy


## Arguments


### Total cost for all Electric Equipment Controls in the Building ($).

**Name:** costTotal,
**Type:** Double,
**Units:** ,
**Required:** true,
**Model Dependent:** false




