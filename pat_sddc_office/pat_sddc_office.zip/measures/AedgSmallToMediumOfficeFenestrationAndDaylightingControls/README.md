

###### (Automatically generated documentation)

# AedgSmallToMediumOfficeFenestrationAndDaylightingControls

## Description


## Modeler Description


## Measure Type
ModelMeasure

## Taxonomy


## Arguments


### Cost per Area for Proposed Daylighting Window Constructions ($/ft^2).

**Name:** cost_daylight_glazing,
**Type:** Double,
**Units:** ,
**Required:** true,
**Model Dependent:** false

### Cost per Area for Proposed View Window Constructions ($/ft^2).

**Name:** cost_view_glazing,
**Type:** Double,
**Units:** ,
**Required:** true,
**Model Dependent:** false

### Cost per Area for Proposed Skylight Construction ($/ft^2).

**Name:** cost_skylight,
**Type:** Double,
**Units:** ,
**Required:** true,
**Model Dependent:** false

### Cost per Area for Proposed Exterior Shading Surface Construction ($/ft^2).

**Name:** cost_shading_surface,
**Type:** Double,
**Units:** ,
**Required:** true,
**Model Dependent:** false

### Cost per Area for Proposed Light Shelf Construction ($/ft^2).

**Name:** cost_light_shelf,
**Type:** Double,
**Units:** ,
**Required:** true,
**Model Dependent:** false




