

###### (Automatically generated documentation)

# ViewModel

## Description
Visualize an OpenStudio model in a web based viewer

## Modeler Description
Converts the OpenStudio model to vA3C JSON format and renders using Three.js

## Measure Type
ModelMeasure

## Taxonomy


## Arguments




This measure does not have any user arguments


