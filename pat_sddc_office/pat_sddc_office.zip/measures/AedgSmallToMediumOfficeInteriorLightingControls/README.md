

###### (Automatically generated documentation)

# AedgSmallToMediumOfficeInteriorLightingControls

## Description


## Modeler Description


## Measure Type
ModelMeasure

## Taxonomy


## Arguments


### Total cost for all Lighting Controls in the Building ($).

**Name:** costTotal,
**Type:** Double,
**Units:** ,
**Required:** true,
**Model Dependent:** false




