

###### (Automatically generated documentation)

# Create and Assign Thermal Zones for Unassigned Spaces

## Description
If any spaces are not part of a thermal zone, then this measure will create a new thermal zone and assign it to the space.

## Modeler Description
Thermal zones will be named after the spac with a prefix added

## Measure Type
ModelMeasure

## Taxonomy


## Arguments




This measure does not have any user arguments


