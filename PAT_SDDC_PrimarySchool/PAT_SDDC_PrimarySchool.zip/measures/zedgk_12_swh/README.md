

###### (Automatically generated documentation)

# ZEDG K12 SWH

## Description


## Modeler Description


## Measure Type
ModelMeasure

## Taxonomy


## Arguments


### Total Cost for Kitchen System ($).

**Name:** costTotalSwhSystem,
**Type:** Double,
**Units:** ,
**Required:** true,
**Model Dependent:** false

### Total Number of Students.

**Name:** numberOfStudents,
**Type:** Integer,
**Units:** ,
**Required:** true,
**Model Dependent:** false




