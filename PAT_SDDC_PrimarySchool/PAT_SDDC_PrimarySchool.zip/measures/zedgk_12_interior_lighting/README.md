

###### (Automatically generated documentation)

# ZEDG K12 Interior Lighting

## Description


## Modeler Description


## Measure Type
ModelMeasure

## Taxonomy


## Arguments


### Material and Installation Costs for Lights per Floor Area ($/ft^2).

**Name:** material_cost_ip,
**Type:** Double,
**Units:** ,
**Required:** true,
**Model Dependent:** false




