

###### (Automatically generated documentation)

# AedgK12InteriorFinishes

## Description


## Modeler Description


## Measure Type
ModelMeasure

## Taxonomy


## Arguments


### Only Check/Alter Interior Partition Surfaces To Meet Furniture Target When They Use This Construction.

**Name:** object,
**Type:** Choice,
**Units:** ,
**Required:** true,
**Model Dependent:** false




