

###### (Automatically generated documentation)

# ZEDG K12 RoofConstruction

## Description


## Modeler Description


## Measure Type
ModelMeasure

## Taxonomy


## Arguments


### Increase Cost per Area of Construction Where Insulation was Improved ($/ft^2).

**Name:** material_cost_insulation_increase_ip,
**Type:** Double,
**Units:** ,
**Required:** true,
**Model Dependent:** false

### Increase Cost per Area of Construction Where Solar Reflectance Index (SRI) was Improved. ($/ft^2).

**Name:** material_cost_sri_increase_ip,
**Type:** Double,
**Units:** ,
**Required:** true,
**Model Dependent:** false

### Alter SRI?

**Name:** alter_sri,
**Type:** Boolean,
**Units:** ,
**Required:** true,
**Model Dependent:** false




