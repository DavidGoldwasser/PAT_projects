

###### (Automatically generated documentation)

# Set Thermostat Schedules

## Description


## Modeler Description


## Measure Type
ModelMeasure

## Taxonomy


## Arguments


### Choose Thermal Zones to change thermostat schedules on.

**Name:** zones,
**Type:** Choice,
**Units:** ,
**Required:** true,
**Model Dependent:** false

### Choose Cooling Schedule.

**Name:** cooling_sch,
**Type:** Choice,
**Units:** ,
**Required:** true,
**Model Dependent:** false

### Choose Heating Schedule.

**Name:** heating_sch,
**Type:** Choice,
**Units:** ,
**Required:** true,
**Model Dependent:** false

### Material and Installation Costs per Thermal Zone ($/thermal zone).

**Name:** material_cost,
**Type:** Double,
**Units:** ,
**Required:** true,
**Model Dependent:** false




