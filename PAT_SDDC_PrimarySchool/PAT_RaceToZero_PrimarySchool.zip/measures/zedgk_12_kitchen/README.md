

###### (Automatically generated documentation)

# ZEDG K12 Kitchen

## Description


## Modeler Description


## Measure Type
ModelMeasure

## Taxonomy


## Arguments


### Total Cost for Kitchen System ($).

**Name:** costTotalKitchenSystem,
**Type:** Double,
**Units:** ,
**Required:** true,
**Model Dependent:** false

### Total Number of Students.

**Name:** numberOfStudents,
**Type:** Integer,
**Units:** ,
**Required:** true,
**Model Dependent:** false




