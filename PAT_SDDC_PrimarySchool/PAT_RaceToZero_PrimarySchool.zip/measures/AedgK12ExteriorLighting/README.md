

###### (Automatically generated documentation)

# AedgK12ExteriorLighting

## Description


## Modeler Description


## Measure Type
ModelMeasure

## Taxonomy


## Arguments


### Exterior Lighting Target Performance

**Name:** target,
**Type:** Choice,
**Units:** ,
**Required:** true,
**Model Dependent:** false

### Exterior Lighting Zone

**Name:** lightingZone,
**Type:** Choice,
**Units:** ,
**Required:** true,
**Model Dependent:** false

### Wall Coverage Area for Decorative Facade Lighting (ft^2)

**Name:** facadeLandscapeLighting,
**Type:** Double,
**Units:** ,
**Required:** true,
**Model Dependent:** false

### Ground Coverage Area for Parking Lots and Drives Lighting (ft^2)

**Name:** parkingDrivesLighting,
**Type:** Double,
**Units:** ,
**Required:** true,
**Model Dependent:** false

### Ground Coverage Area for Walkway and Plaza Lighting (ft^2)

**Name:** walkwayPlazaSpecialLighting,
**Type:** Double,
**Units:** ,
**Required:** true,
**Model Dependent:** false

### Total cost for all Exterior Lighting ($).

**Name:** costTotalExteriorLights,
**Type:** Double,
**Units:** ,
**Required:** true,
**Model Dependent:** false




