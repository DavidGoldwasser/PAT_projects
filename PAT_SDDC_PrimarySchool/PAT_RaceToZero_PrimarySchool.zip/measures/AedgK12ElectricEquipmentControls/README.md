

###### (Automatically generated documentation)

# AedgK12ElectricEquipmentControls

## Description


## Modeler Description


## Measure Type
ModelMeasure

## Taxonomy


## Arguments


### Total cost for all Equipment Controls in the Building ($).

**Name:** costTotal,
**Type:** Double,
**Units:** ,
**Required:** true,
**Model Dependent:** false




