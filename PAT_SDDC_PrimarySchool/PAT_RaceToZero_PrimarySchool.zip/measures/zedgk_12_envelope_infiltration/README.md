

###### (Automatically generated documentation)

# ZEDG K12 Envelope Infiltration

## Description


## Modeler Description


## Measure Type
ModelMeasure

## Taxonomy


## Arguments


### Total cost for all Envelope Improvements ($).

**Name:** costTotalEnvelopeInfiltration,
**Type:** Double,
**Units:** ,
**Required:** true,
**Model Dependent:** false




