

###### (Automatically generated documentation)

# AedgSmallToMediumOfficeElectricEquipment

## Description


## Modeler Description


## Measure Type
ModelMeasure

## Taxonomy


## Arguments


### Material and Installation Costs for Electric Equipment per Floor Area ($/ft^2).

**Name:** material_cost_ip,
**Type:** Double,
**Units:** ,
**Required:** true,
**Model Dependent:** false




