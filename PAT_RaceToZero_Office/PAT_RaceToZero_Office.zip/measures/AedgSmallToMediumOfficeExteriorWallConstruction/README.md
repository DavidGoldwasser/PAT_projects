

###### (Automatically generated documentation)

# AedgSmallToMediumOfficeExteriorWallConstruction

## Description


## Modeler Description


## Measure Type
ModelMeasure

## Taxonomy


## Arguments


### Increase Cost per Area of Construction Where Insulation was Improved ($/ft^2).

**Name:** material_cost_insulation_increase_ip,
**Type:** Double,
**Units:** ,
**Required:** true,
**Model Dependent:** false




